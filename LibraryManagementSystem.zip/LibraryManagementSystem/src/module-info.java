/**
 * 
 */
/**
 * @author Bichoy Emad
 *
 */
module LibraryManagementSystem {
	requires java.desktop;
}